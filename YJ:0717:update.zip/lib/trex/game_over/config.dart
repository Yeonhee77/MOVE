class GameOverConfig {
  late final double textWidth = 231.0;
  late final double textHeight = 36.0;
  late final double restartWidth = 111.0; //button design ver.
  late final double restartHeight = 80.0; //button design ver.
  late final double scoreWidth = 191.0;
  late final double scoreHeight = 50.0;
}
