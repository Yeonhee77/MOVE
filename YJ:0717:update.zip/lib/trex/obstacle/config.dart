class ObstacleConfig {
  late final int maxObstacleLength = 1;
  late final double maxGapCoefficient = 1.5;
}
