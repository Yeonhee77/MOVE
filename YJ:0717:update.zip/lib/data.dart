class Move{
 int gdata;

 Move(this.gdata);

}